"use client"

import { useState, useEffect, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { 
  CheckCircle2, 
  XCircle, 
  MapPin, 
  Phone, 
  User, 
  RefreshCw, 
  Edit2, 
  Download,
  ExternalLink,
  Search,
  Home,
  Calendar,
  Flag,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Users,
  FileSpreadsheet
} from "lucide-react"
import * as XLSX from "xlsx"
import { saveAs } from "file-saver"

// Types
interface Resident {
  id: string
  nom: string
  prenom: string
  pays: string
  naiss: string
  tel: string
  chambre: string
}

interface Apartment {
  id: string
  numero: string
  rue: string
  cp: string
  commune: string
  etage: string
  obs: string
  codes: string
  residents: Resident[]
}

interface RouteStop {
  aptId: string
  order: number
  details: string
}

interface Route {
  id: string
  title: string
  tourIndex: number
  stops: RouteStop[]
}

interface Responsable {
  name: string
  phone: string
}

interface SharedData {
  presence: Record<string, { tour1: string | null; tour2: string | null; userId?: string }>
  events: Record<string, string>
  checked: Record<string, boolean>
  signalements: Record<string, string>
  aptSignalements: Record<string, string>
}

// Routes data - Colomb dans tournee 1
const ROUTES: Route[] = [
  {
    id: "t1",
    title: "1ere tournee",
    tourIndex: 0,
    stops: [
      { aptId: "apt-10", order: 1, details: "Bd Mitterrand, 11eme etage" },
      { aptId: "apt-2", order: 2, details: "Jarlan, 5eme etage, porte de droite" },
      { aptId: "apt-6", order: 3, details: "Lalande, 13eme etage" },
      { aptId: "apt-19", order: 4, details: "Dereure" },
      { aptId: "apt-11", order: 5, details: "Allemane (1), 1er etage" },
      { aptId: "apt-3", order: 6, details: "Allemane (2), 2eme etage" },
      { aptId: "apt-12", order: 7, details: "Allemane (3), 4eme etage" },
      { aptId: "apt-18", order: 8, details: "Delecluze" },
      { aptId: "apt-17", order: 9, details: "Cerise, bat. 6, RDC droite, porte 17" },
      { aptId: "apt-8", order: 10, details: "Reclus, 3eme etage, porte 17" },
      { aptId: "apt-15", order: 11, details: "Colombe, 2eme etage" },
    ],
  },
  {
    id: "t2",
    title: "2eme tournee",
    tourIndex: 1,
    stops: [
      { aptId: "apt-9", order: 1, details: "Village, dernier etage, porte de droite" },
      { aptId: "apt-1", order: 2, details: "Alexandre, code 1973, porte a droite" },
      { aptId: "apt-13", order: 3, details: "Alexandre, 2eme etage, porte a droite" },
      { aptId: "apt-14", order: 4, details: "Biches (2), 11eme etage, porte de gauche" },
      { aptId: "apt-20", order: 5, details: "Biches (1), 4eme etage, porte de gauche" },
      { aptId: "apt-5", order: 6, details: "Pierre & Marie Curie, code 53A19, 4eme etage" },
      { aptId: "apt-7", order: 7, details: "Dragon, 5eme etage, droite" },
      { aptId: "apt-16", order: 8, details: "Biere, 1er etage gauche" },
      { aptId: "apt-4", order: 9, details: "Courcouronnes, bat. 42, 2eme etage" },
    ],
  },
]

// Responsables par appartement
const RESPONSABLES_DEFAULT: Record<string, Responsable[]> = {
  "apt-1": [{ name: "Angelique", phone: "06.22.87.83.43" }],
  "apt-2": [{ name: "Thomas", phone: "" }],
  "apt-3": [{ name: "Kaissa", phone: "06.18.71.52.36" }],
  "apt-4": [{ name: "Stephane", phone: "06.30.28.46.50" }],
  "apt-5": [{ name: "Rabiatou", phone: "07.85.56.41.18" }],
  "apt-6": [{ name: "Stephane", phone: "06.30.28.46.50" }],
  "apt-7": [{ name: "Stephane", phone: "06.30.28.46.50" }],
  "apt-8": [{ name: "Nabil", phone: "06.09.09.32.95" }],
  "apt-9": [{ name: "Ferhat", phone: "06.11.99.02.02" }],
  "apt-10": [{ name: "Ferhat", phone: "06.11.99.02.02" }],
  "apt-11": [{ name: "Kaissa", phone: "06.18.71.52.36" }],
  "apt-12": [{ name: "Megane", phone: "06.30.10.74.84" }],
  "apt-13": [{ name: "Megane", phone: "06.30.10.74.84" }],
  "apt-14": [{ name: "Fatoumata", phone: "06.22.87.83.43" }],
  "apt-15": [{ name: "Shaima", phone: "06.22.87.83.43" }],
  "apt-16": [{ name: "Ferhat", phone: "06.11.99.02.02" }],
  "apt-17": [{ name: "Angelique", phone: "06.22.87.83.43" }],
  "apt-18": [{ name: "Rabiatou", phone: "07.85.56.41.18" }],
  "apt-19": [{ name: "Thomas", phone: "06.31.59.96.02" }],
  "apt-20": [{ name: "Shaima", phone: "06.22.87.83.43" }],
}

// Donnees des appartements - Square de la Biere (corrige)
const DEFAULT_APARTMENTS: Apartment[] = [
  {
    id: "apt-1",
    numero: "12",
    rue: "Rue Alexandre Soljenitsyne",
    cp: "91000",
    commune: "EVRY",
    etage: "3eme",
    obs: "Porte a droite, dernier etage",
    codes: "Code 1973",
    residents: [
      { id: "r1", nom: "LUAMBA", prenom: "Ravie", pays: "Congo", naiss: "06/08/2008", tel: "07.49.22.64.99", chambre: "" },
      { id: "r2", nom: "HMIDA", prenom: "Linda", pays: "Tunisie", naiss: "21/01/2007", tel: "06.24.82.28.54", chambre: "" },
      { id: "r3", nom: "MENGA NOTAM", prenom: "Marguerite", pays: "Cameroun", naiss: "09/02/2008", tel: "06.41.35.91.76", chambre: "" },
      { id: "r4", nom: "VALLA", prenom: "Fall", pays: "Senegal", naiss: "19/07/2008", tel: "07.51.37.05.42", chambre: "" },
    ],
  },
  {
    id: "apt-2",
    numero: "6",
    rue: "Rue du Pere Andre Jarlan",
    cp: "91000",
    commune: "EVRY",
    etage: "5eme",
    obs: "Porte de droite",
    codes: "Entree : 1310  Interieur : B0502",
    residents: [
      { id: "r7", nom: "TSESSIE", prenom: "Jaures", pays: "Cameroun", naiss: "31/10/2005", tel: "07.45.05.54.44", chambre: "" },
      { id: "r8", nom: "DABBAK", prenom: "Rayen", pays: "Tunisie", naiss: "18/02/2005", tel: "07.44.29.59.05", chambre: "" },
      { id: "r9", nom: "DEMBA", prenom: "Gassama", pays: "Mali", naiss: "21/02/2008", tel: "07.53.10.33.03", chambre: "" },
      { id: "r107", nom: "SORO", prenom: "Sana", pays: "Cote d'Ivoire", naiss: "28/12/2008", tel: "06.69.77.86.14", chambre: "" },
      { id: "r108", nom: "GHZAEIL", prenom: "Mohamed Amine", pays: "Tunisie", naiss: "21/01/2006", tel: "07.58.67.96.10", chambre: "" },
      { id: "r109", nom: "BELMILOUD", prenom: "Heythem", pays: "Algerie", naiss: "14/06/2008", tel: "07.58.02.08.72", chambre: "" },
      { id: "r110", nom: "KONATE", prenom: "Moussa", pays: "Guinee", naiss: "20/04/2007", tel: "07.58.89.25.01", chambre: "" },
    ],
  },
  {
    id: "apt-3",
    numero: "3",
    rue: "Square Jean Allemane",
    cp: "91000",
    commune: "EVRY",
    etage: "2eme",
    obs: "Pas d'ascenseur",
    codes: "Badge",
    residents: [
      { id: "r44", nom: "KONE", prenom: "El Mohamedi", pays: "Cote d'Ivoire", naiss: "04/11/2006", tel: "06.68.24.10.15", chambre: "" },
      { id: "r45", nom: "BOURRAS", prenom: "Oussama", pays: "Algerie", naiss: "14/03/2008", tel: "07.44.11.71.06", chambre: "" },
      { id: "r46", nom: "BAKAYOKO", prenom: "Ali", pays: "Cote d'Ivoire", naiss: "21/04/2006", tel: "07.53.27.45.58", chambre: "" },
      { id: "r47", nom: "JALLOW", prenom: "Thierno Ibrahim", pays: "Guinee", naiss: "10/12/2006", tel: "07.74.98.24.28", chambre: "" },
    ],
  },
  {
    id: "apt-4",
    numero: "42",
    rue: "Rue du Marquis de Raies",
    cp: "91080",
    commune: "COURCOURONNES",
    etage: "2eme",
    obs: "Batiment 42, porte de droite. Medicaments.",
    codes: "Badge",
    residents: [
      { id: "r11", nom: "ARDJOUN", prenom: "Ahmed Rayene", pays: "Algerie", naiss: "04/01/2009", tel: "06.35.01.47.64", chambre: "" },
      { id: "r12", nom: "KOUROUMA", prenom: "Mohamed", pays: "Guinee", naiss: "15/11/2007", tel: "07.58.83.99.12", chambre: "" },
      { id: "r13", nom: "SOUMARE", prenom: "Issa", pays: "Cote d'Ivoire", naiss: "17/06/2008", tel: "07.44.29.04.50", chambre: "" },
      { id: "r14", nom: "COULIBALY", prenom: "Boubakar", pays: "Mauritanie", naiss: "01/01/2005", tel: "07.74.11.07.74", chambre: "" },
    ],
  },
  {
    id: "apt-5",
    numero: "203",
    rue: "Rue Pierre et Marie Curie",
    cp: "91000",
    commune: "EVRY",
    etage: "4eme",
    obs: "4eme etage A, porte en face",
    codes: "Entree : 53A19",
    residents: [
      { id: "r15", nom: "DOUMBIA", prenom: "Idrissa", pays: "Cote d'Ivoire", naiss: "04/12/2006", tel: "07.44.27.49.63", chambre: "" },
      { id: "r16", nom: "MANNEH", prenom: "Famara", pays: "Gambie", naiss: "06/02/2008", tel: "07.48.40.72.22", chambre: "" },
      { id: "r17", nom: "KHENISSI", prenom: "Sofiane", pays: "Tunisie", naiss: "17/10/2006", tel: "07.58.07.75.03", chambre: "" },
      { id: "r18", nom: "SYLLA", prenom: "Younoussa", pays: "Guinee", naiss: "28/06/2007", tel: "06.12.65.89.61", chambre: "" },
    ],
  },
  {
    id: "apt-6",
    numero: "3",
    rue: "Rue Andre Lalande",
    cp: "91000",
    commune: "EVRY",
    etage: "13eme",
    obs: "1ere porte a droite",
    codes: "Portillon : 0911 / Entrees : 1720 / Interphone : 1136",
    residents: [
      { id: "r19", nom: "BAH", prenom: "Mamadou Lamanara", pays: "Guinee", naiss: "05/10/2008", tel: "07.59.35.42.84", chambre: "" },
      { id: "r20", nom: "ISSA NGWAMBI", prenom: "Said Ibrahim", pays: "Congo", naiss: "02/08/2005", tel: "07.53.17.08.75", chambre: "" },
      { id: "r21", nom: "OUERRADI", prenom: "Mohamed", pays: "Maroc", naiss: "20/03/2008", tel: "07.61.42.20.73", chambre: "" },
      { id: "r22", nom: "DIALLO", prenom: "Abdoul Razac", pays: "Guinee", naiss: "15/04/2008", tel: "07.58.30.93.43", chambre: "" },
      { id: "r23", nom: "BEN ALI", prenom: "Omar", pays: "Tunisie", naiss: "05/01/2009", tel: "07.51.41.29.39", chambre: "" },
    ],
  },
  {
    id: "apt-7",
    numero: "306",
    rue: "Allee du Dragon",
    cp: "91000",
    commune: "EVRY",
    etage: "5eme",
    obs: "5eme etage, porte 123 a droite de l'ascenseur",
    codes: "Badge",
    residents: [
      { id: "r115", nom: "KONE", prenom: "Sindou Razak", pays: "Cote d'Ivoire", naiss: "16/12/2006", tel: "06.44.87.75.34", chambre: "" },
      { id: "r116", nom: "MAYEMBA", prenom: "Jael", pays: "Congo", naiss: "12/12/2006", tel: "07.59.81.63.83", chambre: "" },
      { id: "r117", nom: "KONE", prenom: "Vali", pays: "Cote d'Ivoire", naiss: "01/05/2008", tel: "07.53.91.92.22", chambre: "" },
      { id: "r118", nom: "CISSE", prenom: "Alpha", pays: "Guinee", naiss: "01/10/2007", tel: "07.51.03.57.40", chambre: "" },
      { id: "r119", nom: "BANGURA", prenom: "Oumar", pays: "Sierra Leone", naiss: "01/01/2007", tel: "06.26.67.66.02", chambre: "" },
    ],
  },
  {
    id: "apt-8",
    numero: "15",
    rue: "Square Elie Reclus",
    cp: "91000",
    commune: "EVRY",
    etage: "3eme",
    obs: "3eme etage, porte 17",
    codes: "Badge",
    residents: [
      { id: "r24", nom: "TRAORE", prenom: "Mamadou", pays: "Mali", naiss: "22/12/2006", tel: "07.49.24.58.49", chambre: "" },
      { id: "r25", nom: "GARCIA DA CONCEICAO", prenom: "Pedro", pays: "Angola", naiss: "11/06/2008", tel: "07.58.58.63.36", chambre: "" },
      { id: "r26", nom: "TRAORE", prenom: "Moussa", pays: "Guinee", naiss: "01/10/2005", tel: "07.58.24.50.84", chambre: "" },
      { id: "r27", nom: "DIALLO", prenom: "Abdallah", pays: "Guinee", naiss: "04/04/2008", tel: "06.04.91.06.72", chambre: "" },
    ],
  },
  {
    id: "apt-9",
    numero: "4",
    rue: "Rue du Village",
    cp: "91080",
    commune: "COURCOURONNES",
    etage: "Dernier etage",
    obs: "Porte de droite, porte n 232",
    codes: "Badge",
    residents: [
      { id: "r28", nom: "KOUROUMA", prenom: "Kalil", pays: "Guinee", naiss: "05/04/2007", tel: "07.58.38.70.61", chambre: "" },
      { id: "r29", nom: "METHANI", prenom: "Ahmed", pays: "Tunisie", naiss: "17/09/2006", tel: "07.44.14.17.76", chambre: "" },
      { id: "r30", nom: "SYLLA", prenom: "Mohamed Mansour", pays: "Cote d'Ivoire", naiss: "28/05/2007", tel: "06.05.86.65.96", chambre: "" },
      { id: "r31", nom: "DIENE", prenom: "Modou", pays: "Senegal", naiss: "08/07/2007", tel: "07.49.22.64.99", chambre: "" },
    ],
  },
  {
    id: "apt-10",
    numero: "31",
    rue: "Boulevard Francois Mitterrand",
    cp: "91000",
    commune: "EVRY",
    etage: "11eme",
    obs: "En sortant de l'ascenseur a droite puis a gauche",
    codes: "1eres portes: 0721 / 3eme porte: A0707B",
    residents: [
      { id: "r100", nom: "TOURE", prenom: "Mory", pays: "Cote d'Ivoire", naiss: "01/01/2008", tel: "06.05.50.50.81", chambre: "" },
      { id: "r101", nom: "MOHAMED WARSAME", prenom: "Abdelfatah", pays: "Somalie", naiss: "05/05/2008", tel: "07.80.18.75.62", chambre: "" },
      { id: "r102", nom: "KOY KAPULUTA", prenom: "Samuel", pays: "Congo", naiss: "20/05/2006", tel: "07.80.23.90.52", chambre: "" },
      { id: "r103", nom: "DJELLOUL DAOUDJI", prenom: "Ala Eddine", pays: "Algerie", naiss: "14/11/2007", tel: "07.80.51.72.39", chambre: "" },
      { id: "r104", nom: "BAMBA", prenom: "Adam", pays: "Cote d'Ivoire", naiss: "07/04/2008", tel: "07.53.06.85.05", chambre: "" },
      { id: "r105", nom: "SOUMAHORO", prenom: "Mamoudou", pays: "Cote d'Ivoire", naiss: "09/11/2008", tel: "07.53.66.28.49", chambre: "" },
    ],
  },
  {
    id: "apt-11",
    numero: "8",
    rue: "Square Jean Allemane",
    cp: "91000",
    commune: "EVRY",
    etage: "1er",
    obs: "1er etage",
    codes: "",
    residents: [
      { id: "r38", nom: "BELTAIF", prenom: "Ayoub", pays: "Tunisie", naiss: "11/05/2006", tel: "07.53.73.48.16", chambre: "" },
      { id: "r39", nom: "GAMMOUDI", prenom: "Ayoub", pays: "Tunisie", naiss: "04/07/2007", tel: "06.05.94.72.54", chambre: "" },
      { id: "r40", nom: "BARRY", prenom: "Mamadou Saidou", pays: "Guinee", naiss: "03/03/2008", tel: "07.58.76.14.83", chambre: "" },
      { id: "r41", nom: "TRAORE", prenom: "Amara", pays: "Guinee", naiss: "22/12/2006", tel: "07.58.97.36.90", chambre: "" },
      { id: "r42", nom: "GOKE", prenom: "Rayann", pays: "Cote d'Ivoire", naiss: "24/10/2006", tel: "07.44.28.43.15", chambre: "" },
      { id: "r43", nom: "BEN ALI", prenom: "Wael", pays: "Tunisie", naiss: "03/10/2007", tel: "07.53.13.94.74", chambre: "" },
    ],
  },
  {
    id: "apt-12",
    numero: "3",
    rue: "Square Jean Allemane",
    cp: "91000",
    commune: "EVRY",
    etage: "4eme",
    obs: "4eme etage",
    codes: "Badge",
    residents: [
      { id: "r48", nom: "GHALY", prenom: "Ebram Emad", pays: "Egypte", naiss: "17/06/2007", tel: "06.99.13.91.16", chambre: "" },
      { id: "r49", nom: "LUSALA", prenom: "Tariq", pays: "Congo", naiss: "22/01/2007", tel: "07.49.69.35.79", chambre: "" },
      { id: "r50", nom: "CISSE", prenom: "Mohamed Lamine", pays: "Cote d'Ivoire", naiss: "25/11/2007", tel: "06.56.80.21.37", chambre: "" },
      { id: "r51", nom: "HAMIDI", prenom: "Riadh", pays: "Tunisie", naiss: "17/05/2006", tel: "+216.29.681.393", chambre: "" },
      { id: "r52", nom: "DIALLO", prenom: "Boubacar", pays: "Guinee", naiss: "03/06/2006", tel: "06.04.06.40.69", chambre: "" },
      { id: "r53", nom: "TRAORE", prenom: "Lamine", pays: "Guinee", naiss: "20/11/2006", tel: "06.04.43.19.09", chambre: "" },
    ],
  },
  {
    id: "apt-13",
    numero: "18",
    rue: "Rue Alexandre Soljenitsyne",
    cp: "91000",
    commune: "EVRY",
    etage: "2eme",
    obs: "2eme etage, porte a droite. 4 mineurs.",
    codes: "Badge",
    residents: [
      { id: "r84", nom: "LUSE MISSO", prenom: "Prefina", pays: "Congo", naiss: "06/05/2009", tel: "07.44.22.21.85", chambre: "" },
      { id: "r85", nom: "NDOMBELE", prenom: "Joela", pays: "Congo", naiss: "10/06/2008", tel: "07.51.07.16.74", chambre: "" },
      { id: "r86", nom: "AUROUDI", prenom: "Loujayn", pays: "Tunisie", naiss: "10/08/2008", tel: "07.58.46.77.52", chambre: "" },
      { id: "r87", nom: "KALEMBUE", prenom: "Audrey", pays: "Cote d'Ivoire", naiss: "25/11/2008", tel: "07.51.10.12.51", chambre: "" },
    ],
  },
  {
    id: "apt-14",
    numero: "7",
    rue: "Rue Parc aux Biches",
    cp: "91000",
    commune: "EVRY",
    etage: "11eme",
    obs: "11eme etage, porte de gauche",
    codes: "Badge",
    residents: [
      { id: "r88", nom: "DIABATE", prenom: "Abdoulkarim", pays: "Guinee", naiss: "30/06/2007", tel: "07.58.37.45.06", chambre: "" },
      { id: "r89", nom: "DIANE", prenom: "Mory", pays: "Guinee", naiss: "10/01/2007", tel: "07.58.38.44.33", chambre: "" },
      { id: "r90", nom: "BARRY", prenom: "Ramadan", pays: "Guinee", naiss: "25/12/2008", tel: "07.48.54.96.89", chambre: "" },
      { id: "r91", nom: "DIALLO", prenom: "Ibrahima Sory", pays: "Guinee", naiss: "16/04/2008", tel: "07.58.76.20.98", chambre: "" },
      { id: "r92", nom: "DIALLO", prenom: "Ibrahim", pays: "Guinee", naiss: "20/10/2008", tel: "07.58.41.36.38", chambre: "" },
      { id: "r93", nom: "BAKAYOKO", prenom: "Mory", pays: "Cote d'Ivoire", naiss: "24/12/2006", tel: "07.44.17.37.69", chambre: "" },
    ],
  },
  {
    id: "apt-15",
    numero: "12",
    rue: "Place Christophe Colomb",
    cp: "91000",
    commune: "EVRY",
    etage: "2eme",
    obs: "2eme etage. Pas d'ascenseur. Porte n 12",
    codes: "Badge",
    residents: [
      { id: "r62", nom: "DIOMBANA", prenom: "Tama", pays: "Mali", naiss: "11/05/2005", tel: "06.05.70.42.16", chambre: "1" },
      { id: "r63", nom: "KOUROUMA", prenom: "Morissanda", pays: "Guinee", naiss: "08/03/2008", tel: "07.44.11.54.61", chambre: "2" },
      { id: "r64", nom: "BOUAOUA", prenom: "Amir", pays: "Tunisie", naiss: "26/12/2006", tel: "06.05.82.26.91", chambre: "3" },
      { id: "r65", nom: "MALLA", prenom: "Islam", pays: "Algerie", naiss: "26/08/2007", tel: "07.53.38.90.81", chambre: "" },
    ],
  },
  {
    id: "apt-16",
    numero: "1",
    rue: "Square de la Biere",
    cp: "91130",
    commune: "EVRY",
    etage: "1er",
    obs: "1er etage gauche, 1ere porte a gauche",
    codes: "Badge",
    residents: [
      { id: "r66", nom: "KAMARA", prenom: "Daouda", pays: "Guinee", naiss: "01/03/2007", tel: "07.59.82.28.10", chambre: "" },
      { id: "r67", nom: "DIALLO", prenom: "Alpha Oumar", pays: "Guinee", naiss: "14/02/2007", tel: "07.45.13.02.04", chambre: "" },
      { id: "r68", nom: "KAMATE", prenom: "Moussa", pays: "Cote d'Ivoire", naiss: "01/01/2008", tel: "07.58.34.82.64", chambre: "" },
      { id: "r69", nom: "TOURE", prenom: "Mory", pays: "Cote d'Ivoire", naiss: "01/01/2008", tel: "06.05.50.50.81", chambre: "" },
    ],
  },
  {
    id: "apt-17",
    numero: "6",
    rue: "Mails le Temps des Cerises",
    cp: "91130",
    commune: "EVRY",
    etage: "RDC",
    obs: "Batiment 6, RDC droite, porte 17",
    codes: "Badge",
    residents: [
      { id: "r70", nom: "DOUBOUYA", prenom: "Moussa", pays: "Cote d'Ivoire", naiss: "20/11/2007", tel: "07.44.25.60.54", chambre: "" },
      { id: "r71", nom: "KOUROUMA", prenom: "Ousmane Aly", pays: "Guinee", naiss: "28/08/2008", tel: "07.51.26.16.99", chambre: "" },
      { id: "r72", nom: "BALDE", prenom: "Thierno Seydou", pays: "Guinee", naiss: "12/11/2008", tel: "07.59.79.85.83", chambre: "" },
      { id: "r73", nom: "CAMARA", prenom: "Bangaly", pays: "Cote d'Ivoire", naiss: "01/08/2007", tel: "07.51.02.03.42", chambre: "" },
    ],
  },
  {
    id: "apt-18",
    numero: "2",
    rue: "Villa Charles Delescluze",
    cp: "91000",
    commune: "EVRY",
    etage: "RDC",
    obs: "Petite maison",
    codes: "",
    residents: [
      { id: "r74", nom: "GOHO", prenom: "Anne Marie", pays: "Cote d'Ivoire", naiss: "13/10/2007", tel: "07.59.89.29.22", chambre: "" },
      { id: "r75", nom: "JOURALLAH", prenom: "Amira", pays: "Tunisie", naiss: "26/05/2006", tel: "07.45.98.53.23", chambre: "" },
      { id: "r76", nom: "MAYEMBA", prenom: "Lydie", pays: "Congo", naiss: "16/05/2006", tel: "07.53.93.48.91", chambre: "" },
      { id: "r77", nom: "SIBY", prenom: "Atty", pays: "Mali", naiss: "20/09/2008", tel: "07.44.16.57.30", chambre: "" },
    ],
  },
  {
    id: "apt-19",
    numero: "3",
    rue: "Villa Simon Dereure",
    cp: "91000",
    commune: "EVRY",
    etage: "2eme",
    obs: "2eme etage (Escalier C, 2 portes face droite)",
    codes: "",
    residents: [
      { id: "r78", nom: "TRAORE", prenom: "Lamine", pays: "Cote d'Ivoire", naiss: "20/11/2006", tel: "06.04.43.19.09", chambre: "" },
      { id: "r79", nom: "BAH", prenom: "Sadjo", pays: "Guinee", naiss: "20/05/2008", tel: "07.58.75.09.44", chambre: "" },
      { id: "r80", nom: "LUKIEYE", prenom: "Winner", pays: "Congo", naiss: "13/12/2008", tel: "06.05.98.06.37", chambre: "" },
      { id: "r81", nom: "LAME", prenom: "Serigne Abdou", pays: "Senegal", naiss: "26/01/2007", tel: "07.45.95.05.00", chambre: "" },
      { id: "r82", nom: "SYLLA", prenom: "Alhassane", pays: "Guinee", naiss: "28/12/2008", tel: "06.69.77.86.14", chambre: "" },
    ],
  },
  {
    id: "apt-20",
    numero: "5",
    rue: "Rue du Parc aux Biches",
    cp: "91000",
    commune: "EVRY",
    etage: "4eme",
    obs: "4eme etage, porte de gauche",
    codes: "",
    residents: [
      { id: "r94", nom: "OZPALTA", prenom: "Mustafa", pays: "Turquie", naiss: "16/05/2006", tel: "07.80.50.87.76", chambre: "" },
      { id: "r95", nom: "BARRY", prenom: "Abdoul Karim", pays: "Guinee", naiss: "15/10/2006", tel: "07.58.28.78.46", chambre: "" },
      { id: "r96", nom: "TANDJIGORA", prenom: "Moussa", pays: "Mali", naiss: "06/06/2008", tel: "07.51.07.08.45", chambre: "" },
      { id: "r97", nom: "RAHMAN", prenom: "Fahim", pays: "Bangladesh", naiss: "29/09/2007", tel: "07.77.67.51.19", chambre: "" },
      { id: "r98", nom: "MALEK ZAI", prenom: "Maliar", pays: "Afghanistan", naiss: "03/09/2005", tel: "07.69.00.35.51", chambre: "" },
      { id: "r99", nom: "AMMAR", prenom: "Mohamed Rayen", pays: "Tunisie", naiss: "26/06/2008", tel: "07.51.22.92.98", chambre: "" },
    ],
  },
]

// Codes batiment
const BUILDING_CODES = [
  { label: "Portail", code: "1720" },
  { label: "Porte", code: "7536" },
  { label: "Alarme", code: "3789" },
  { label: "Coffre", code: "2019" },
  { label: "PIN", code: "1962" },
]

// Storage keys
const LS_APTS = "presence_apartments_v3"
const LS_SHARED = "presence_shared_v3"
const LS_USERS = "presence_users_v3"
const LS_CUR_USR = "presence_current_user_v3"
const LS_RESPONSABLES = "presence_responsables_v3"

export default function SuiviPresencePage() {
  const [apartments, setApartments] = useState<Apartment[]>(DEFAULT_APARTMENTS)
  const [sharedData, setSharedData] = useState<SharedData>({ presence: {}, events: {}, checked: {}, signalements: {}, aptSignalements: {} })
  const [users, setUsers] = useState<{ id: string; name: string }[]>([])
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [responsables, setResponsables] = useState<Record<string, Responsable[]>>(RESPONSABLES_DEFAULT)
  const [searchQuery, setSearchQuery] = useState("")
  const [filter, setFilter] = useState<"all" | "present" | "absent">("all")
  const [expandedApts, setExpandedApts] = useState<Set<string>>(new Set())
  
  // Modals
  const [editingResident, setEditingResident] = useState<{ apt: Apartment; resident: Resident } | null>(null)
  const [editingResponsable, setEditingResponsable] = useState<{ aptId: string; resp: Responsable; index: number } | null>(null)
  const [editingSignalement, setEditingSignalement] = useState<{ residentId: string; residentName: string } | null>(null)
  const [editingAptSignalement, setEditingAptSignalement] = useState<{ aptId: string; aptAddress: string } | null>(null)
  const [editingUsers, setEditingUsers] = useState(false)

  // Build route map
  const routeMap = useCallback(() => {
    const map: Record<string, { title: string; order: number; tourIndex: number; details: string }> = {}
    ROUTES.forEach((r) =>
      r.stops.forEach((s) => {
        map[s.aptId] = { title: r.title, order: s.order, tourIndex: r.tourIndex, details: s.details }
      })
    )
    return map
  }, [])

  // Load data from localStorage
  useEffect(() => {
    try {
      const savedApts = localStorage.getItem(LS_APTS)
      if (savedApts) setApartments(JSON.parse(savedApts))
    } catch {
      setApartments(DEFAULT_APARTMENTS)
    }

    try {
      const savedShared = localStorage.getItem(LS_SHARED)
      if (savedShared) {
        const parsed = JSON.parse(savedShared)
        setSharedData({
          presence: parsed.presence || {},
          events: parsed.events || {},
          checked: parsed.checked || {},
          signalements: parsed.signalements || {},
          aptSignalements: parsed.aptSignalements || {},
        })
      }
    } catch {
      setSharedData({ presence: {}, events: {}, checked: {}, signalements: {}, aptSignalements: {} })
    }

    try {
      const savedUsers = localStorage.getItem(LS_USERS)
      if (savedUsers) {
        setUsers(JSON.parse(savedUsers))
      } else {
        // Default 8 users with anonymous names
        const defaultUsers = Array.from({ length: 8 }, (_, i) => ({
          id: `u${i + 1}`,
          name: `Utilisateur ${i + 1}`,
        }))
        setUsers(defaultUsers)
        localStorage.setItem(LS_USERS, JSON.stringify(defaultUsers))
      }
    } catch {
      const defaultUsers = Array.from({ length: 8 }, (_, i) => ({
        id: `u${i + 1}`,
        name: `Utilisateur ${i + 1}`,
      }))
      setUsers(defaultUsers)
    }

    try {
      const savedResponsables = localStorage.getItem(LS_RESPONSABLES)
      if (savedResponsables) setResponsables(JSON.parse(savedResponsables))
    } catch {
      setResponsables(RESPONSABLES_DEFAULT)
    }

    const savedCurUser = localStorage.getItem(LS_CUR_USR)
    if (savedCurUser) setCurrentUserId(savedCurUser)
  }, [])

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem(LS_APTS, JSON.stringify(apartments))
  }, [apartments])

  useEffect(() => {
    localStorage.setItem(LS_SHARED, JSON.stringify(sharedData))
  }, [sharedData])

  useEffect(() => {
    localStorage.setItem(LS_USERS, JSON.stringify(users))
  }, [users])

  useEffect(() => {
    if (currentUserId) localStorage.setItem(LS_CUR_USR, currentUserId)
  }, [currentUserId])

  useEffect(() => {
    localStorage.setItem(LS_RESPONSABLES, JSON.stringify(responsables))
  }, [responsables])

  // Get presence for a resident
  const getPresence = (resId: string) => {
    return sharedData.presence[resId] || { tour1: null, tour2: null }
  }

  // Set presence with userId tracking
  const setPresence = (resId: string, tour: "tour1" | "tour2", value: "present" | "absent") => {
    if (!currentUserId) return
    setSharedData((prev) => {
      const current = prev.presence[resId] || { tour1: null, tour2: null, userId: currentUserId }
      const newValue = current[tour] === value ? null : value
      return {
        ...prev,
        presence: {
          ...prev.presence,
          [resId]: { ...current, [tour]: newValue, userId: currentUserId },
        },
      }
    })
  }

  // Reset my presence (only for current user - only their own data)
  const resetMyPresence = () => {
    if (!currentUserId) return
    if (!confirm("Reinitialiser uniquement VOS presences ? Les donnees des autres utilisateurs seront conservees.")) return
    setSharedData((prev) => {
      const newPresence: typeof prev.presence = {}
      // Keep presence data from other users
      Object.entries(prev.presence).forEach(([resId, data]) => {
        if (data.userId !== currentUserId) {
          newPresence[resId] = data
        }
      })
      return {
        ...prev,
        presence: newPresence,
      }
    })
  }

  // Save signalement
  const saveSignalement = (residentId: string, text: string) => {
    setSharedData((prev) => ({
      ...prev,
      signalements: {
        ...prev.signalements,
        [residentId]: text,
      },
    }))
    setEditingSignalement(null)
  }

  // Save apt signalement
  const saveAptSignalement = (aptId: string, text: string) => {
    setSharedData((prev) => ({
      ...prev,
      aptSignalements: {
        ...prev.aptSignalements,
        [aptId]: text,
      },
    }))
    setEditingAptSignalement(null)
  }

  // Save user name
  const saveUserName = (userId: string, newName: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, name: newName } : u))
    )
  }

  // Save resident changes
  const saveResident = (aptId: string, updatedResident: Resident) => {
    setApartments((prev) =>
      prev.map((apt) =>
        apt.id === aptId
          ? {
              ...apt,
              residents: apt.residents.map((r) => (r.id === updatedResident.id ? updatedResident : r)),
            }
          : apt
      )
    )
    setEditingResident(null)
  }

  // Save responsable changes
  const saveResponsable = (aptId: string, index: number, updatedResp: Responsable) => {
    setResponsables((prev) => {
      const aptResps = [...(prev[aptId] || [])]
      aptResps[index] = updatedResp
      return { ...prev, [aptId]: aptResps }
    })
    setEditingResponsable(null)
  }

  // Export to Excel
  const exportToExcel = () => {
    const exportData = apartments.flatMap((apt) =>
      apt.residents.map((res) => ({
        Nom: res.nom,
        Prenom: res.prenom,
        Adresse: `${apt.numero} ${apt.rue}, ${apt.cp} ${apt.commune}`,
        "Date de Naissance": res.naiss,
        "N Telephone": res.tel,
      }))
    )

    const ws = XLSX.utils.json_to_sheet(exportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Jeunes Heberges")

    ws["!cols"] = [{ wch: 20 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 18 }]

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })
    saveAs(blob, `jeunes-heberges-${new Date().toISOString().split("T")[0]}.xlsx`)
  }

  // Export absences to Excel
  const exportAbsencesToExcel = () => {
    const exportData: { Nom: string; Prenom: string; Adresse: string; "Date de Naissance": string; "N Telephone": string; "Absence Tournee 1": string; "Absence Tournee 2": string }[] = []
    
    apartments.forEach((apt) => {
      apt.residents.forEach((res) => {
        const p = getPresence(res.id)
        if (p.tour1 === "absent" || p.tour2 === "absent") {
          exportData.push({
            Nom: res.nom,
            Prenom: res.prenom,
            Adresse: `${apt.numero} ${apt.rue}, 91100 EVRY`,
            "Date de Naissance": res.naiss,
            "N Telephone": res.tel,
            "Absence Tournee 1": p.tour1 === "absent" ? "Oui" : "Non",
            "Absence Tournee 2": p.tour2 === "absent" ? "Oui" : "Non",
          })
        }
      })
    })

    if (exportData.length === 0) {
      alert("Aucune absence a exporter")
      return
    }

    const ws = XLSX.utils.json_to_sheet(exportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Absences")

    ws["!cols"] = [{ wch: 20 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 18 }, { wch: 18 }, { wch: 18 }]

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })
    saveAs(blob, `absences-${new Date().toISOString().split("T")[0]}.xlsx`)
  }

  // Export signalements to Excel
  const exportSignalementsToExcel = () => {
    const exportData: { Nom: string; Prenom: string; Adresse: string; "Date de Naissance": string; "N Telephone": string; "Evenement a Signaler": string }[] = []
    
    apartments.forEach((apt) => {
      apt.residents.forEach((res) => {
        const signalement = sharedData.signalements[res.id]
        if (signalement && signalement.trim()) {
          exportData.push({
            Nom: res.nom,
            Prenom: res.prenom,
            Adresse: `${apt.numero} ${apt.rue}, 91100 EVRY`,
            "Date de Naissance": res.naiss,
            "N Telephone": res.tel,
            "Evenement a Signaler": signalement,
          })
        }
      })
    })

    if (exportData.length === 0) {
      alert("Aucun evenement a signaler")
      return
    }

    const ws = XLSX.utils.json_to_sheet(exportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Evenements")

    ws["!cols"] = [{ wch: 20 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 18 }, { wch: 50 }]

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })
    saveAs(blob, `evenements-signales-${new Date().toISOString().split("T")[0]}.xlsx`)
  }

  // Export combined absences and signalements to Excel
  const exportCombinedToExcel = () => {
    // Sheet 1: Absences
    const absencesData: { Nom: string; Prenom: string; Adresse: string; "Date de Naissance": string; "N Telephone": string; "Absence Tournee 1": string; "Absence Tournee 2": string }[] = []
    apartments.forEach((apt) => {
      apt.residents.forEach((res) => {
        const p = getPresence(res.id)
        if (p.tour1 === "absent" || p.tour2 === "absent") {
          absencesData.push({
            Nom: res.nom,
            Prenom: res.prenom,
            Adresse: `${apt.numero} ${apt.rue}, 91100 EVRY`,
            "Date de Naissance": res.naiss,
            "N Telephone": res.tel,
            "Absence Tournee 1": p.tour1 === "absent" ? "Oui" : "Non",
            "Absence Tournee 2": p.tour2 === "absent" ? "Oui" : "Non",
          })
        }
      })
    })

    // Sheet 2: Signalements residents
    const signalementsData: { Nom: string; Prenom: string; Adresse: string; "Date de Naissance": string; "N Telephone": string; "Evenement a Signaler": string }[] = []
    apartments.forEach((apt) => {
      apt.residents.forEach((res) => {
        const signalement = sharedData.signalements[res.id]
        if (signalement && signalement.trim()) {
          signalementsData.push({
            Nom: res.nom,
            Prenom: res.prenom,
            Adresse: `${apt.numero} ${apt.rue}, 91100 EVRY`,
            "Date de Naissance": res.naiss,
            "N Telephone": res.tel,
            "Evenement a Signaler": signalement,
          })
        }
      })
    })

    // Sheet 3: Signalements adresses
    const aptSignalementsData: { Adresse: string; "Evenement a Signaler": string }[] = []
    apartments.forEach((apt) => {
      const aptSignalement = sharedData.aptSignalements[apt.id]
      if (aptSignalement && aptSignalement.trim()) {
        aptSignalementsData.push({
          Adresse: `${apt.numero} ${apt.rue}, 91100 EVRY`,
          "Evenement a Signaler": aptSignalement,
        })
      }
    })

    if (absencesData.length === 0 && signalementsData.length === 0 && aptSignalementsData.length === 0) {
      alert("Aucune donnee a exporter")
      return
    }

    const wb = XLSX.utils.book_new()

    if (absencesData.length > 0) {
      const wsAbsences = XLSX.utils.json_to_sheet(absencesData)
      wsAbsences["!cols"] = [{ wch: 20 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 18 }, { wch: 18 }, { wch: 18 }]
      XLSX.utils.book_append_sheet(wb, wsAbsences, "Absences")
    }

    if (signalementsData.length > 0) {
      const wsSignalements = XLSX.utils.json_to_sheet(signalementsData)
      wsSignalements["!cols"] = [{ wch: 20 }, { wch: 20 }, { wch: 50 }, { wch: 15 }, { wch: 18 }, { wch: 50 }]
      XLSX.utils.book_append_sheet(wb, wsSignalements, "Evenements Residents")
    }

    if (aptSignalementsData.length > 0) {
      const wsAptSignalements = XLSX.utils.json_to_sheet(aptSignalementsData)
      wsAptSignalements["!cols"] = [{ wch: 50 }, { wch: 50 }]
      XLSX.utils.book_append_sheet(wb, wsAptSignalements, "Evenements Adresses")
    }

    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })
    saveAs(blob, `rapport-absences-evenements-${new Date().toISOString().split("T")[0]}.xlsx`)
  }

  // Google Maps link for a route - all addresses in EVRY 91100
  const getGoogleMapsLink = (tourIndex: number) => {
    const route = ROUTES.find((r) => r.tourIndex === tourIndex)
    if (!route) return "#"

    const addresses = route.stops
      .map((stop) => {
        const apt = apartments.find((a) => a.id === stop.aptId)
        if (!apt) return null
        return `${apt.numero} ${apt.rue}, 91100 EVRY, France`
      })
      .filter(Boolean)

    if (addresses.length === 0) return "#"

    const waypoints = addresses.map((a) => encodeURIComponent(a!)).join("/")
    return `https://www.google.com/maps/dir/${waypoints}`
  }

  // Calculate stats
  const rMap = routeMap()
  const stats = {
    t1: { present: 0, absent: 0, unmarked: 0 },
    t2: { present: 0, absent: 0, unmarked: 0 },
  }

  apartments.forEach((apt) => {
    const ri = rMap[apt.id]
    if (!ri) return
    const tk = ri.tourIndex === 0 ? "t1" : "t2"
    apt.residents.forEach((res) => {
      const p = getPresence(res.id)
      const v = ri.tourIndex === 0 ? p.tour1 : p.tour2
      if (v === "present") stats[tk].present++
      else if (v === "absent") stats[tk].absent++
      else stats[tk].unmarked++
    })
  })

  // Sort apartments by route
  const sortedApartments = [...apartments].sort((a, b) => {
    const ra = rMap[a.id]
    const rb = rMap[b.id]
    if (ra && rb) {
      if (ra.tourIndex !== rb.tourIndex) return ra.tourIndex - rb.tourIndex
      return ra.order - rb.order
    }
    if (ra) return -1
    if (rb) return 1
    return a.rue.localeCompare(b.rue)
  })

  // Filter apartments
  const filteredApartments = sortedApartments.filter((apt) => {
    if (!searchQuery && filter === "all") return true

    const matchesSearch = apt.residents.some(
      (r) =>
        r.nom.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.prenom.toLowerCase().includes(searchQuery.toLowerCase())
    )

    if (filter === "all") return matchesSearch || !searchQuery

    const hasMatchingStatus = apt.residents.some((r) => {
      const p = getPresence(r.id)
      if (filter === "present") return p.tour1 === "present" || p.tour2 === "present"
      if (filter === "absent") return p.tour1 === "absent" || p.tour2 === "absent"
      return true
    })

    return (matchesSearch || !searchQuery) && hasMatchingStatus
  })

  // Toggle apartment expansion
  const toggleExpand = (aptId: string) => {
    setExpandedApts((prev) => {
      const next = new Set(prev)
      if (next.has(aptId)) next.delete(aptId)
      else next.add(aptId)
      return next
    })
  }

  // Calculate age
  const getAge = (dateStr: string) => {
    if (!dateStr) return ""
    const parts = dateStr.split("/")
    if (parts.length !== 3) return ""
    const birthDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`)
    const today = new Date()
    let age = today.getFullYear() - birthDate.getFullYear()
    if (
      today.getMonth() < birthDate.getMonth() ||
      (today.getMonth() === birthDate.getMonth() && today.getDate() < birthDate.getDate())
    ) {
      age--
    }
    return isNaN(age) ? "" : `${age} ans`
  }

  // Get total residents count
  const totalResidents = apartments.reduce((sum, apt) => sum + apt.residents.length, 0)

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Top Codes Bar */}
      <div className="bg-red-700 text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-center gap-4 text-xs">
          <span className="font-bold uppercase tracking-wider opacity-75">Codes Batiment</span>
          <div className="flex flex-wrap gap-2">
            {BUILDING_CODES.map((c) => (
              <span key={c.label} className="bg-white/15 border border-white/25 rounded px-2 py-1 font-mono">
                <span className="opacity-60 mr-1">{c.label}</span>
                {c.code}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="bg-slate-800 text-white py-4 px-4 sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center text-xl">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold">Suivi de Presence - Jeunes Heberges</h1>
              <p className="text-xs text-white/50">Gestion des adresses et residents</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={exportToExcel} variant="outline" size="sm" className="bg-green-700 hover:bg-green-800 text-white border-green-600">
              <Download className="w-4 h-4 mr-2" />
              Excel (tous)
            </Button>
            <Button onClick={exportCombinedToExcel} variant="outline" size="sm" className="bg-purple-600 hover:bg-purple-700 text-white border-purple-500">
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Excel Absences + Evenements
            </Button>
            <Button onClick={() => setEditingUsers(true)} variant="outline" size="sm" className="bg-blue-600 hover:bg-blue-700 text-white border-blue-500">
              <Users className="w-4 h-4 mr-2" />
              Modifier Utilisateurs
            </Button>
            <Button onClick={resetMyPresence} variant="destructive" size="sm" disabled={!currentUserId}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Reinitialiser mes donnees
            </Button>
          </div>
        </div>
      </header>

      {/* User Selection Bar */}
      <div className="bg-slate-700 py-2 px-4 border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-3">
          <span className="text-xs text-white/50 font-semibold uppercase tracking-wider flex items-center gap-2">
            <User className="w-4 h-4" />
            Utilisateur :
          </span>
          <div className="flex flex-wrap gap-2">
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => setCurrentUserId(u.id)}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                  currentUserId === u.id
                    ? "bg-red-600 text-white border-2 border-red-500"
                    : "bg-white/10 text-white/70 border-2 border-transparent hover:bg-white/20"
                }`}
              >
                {u.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto p-4 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold uppercase tracking-wider text-blue-600 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-600" />
                1ere tournee - Matin
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-green-600">{stats.t1.present}</span>
                  <p className="text-xs uppercase font-semibold text-green-600/60">Presents</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-red-600">{stats.t1.absent}</span>
                  <p className="text-xs uppercase font-semibold text-red-600/60">Absents</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-orange-600">{stats.t1.unmarked}</span>
                  <p className="text-xs uppercase font-semibold text-orange-600/60">Non marques</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold uppercase tracking-wider text-purple-600 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-600" />
                2eme tournee - Soir
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-green-600">{stats.t2.present}</span>
                  <p className="text-xs uppercase font-semibold text-green-600/60">Presents</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-red-600">{stats.t2.absent}</span>
                  <p className="text-xs uppercase font-semibold text-red-600/60">Absents</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-3 text-center">
                  <span className="text-2xl font-bold text-orange-600">{stats.t2.unmarked}</span>
                  <p className="text-xs uppercase font-semibold text-orange-600/60">Non marques</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Routes Overview with Google Maps Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ROUTES.map((route) => (
            <Card key={route.id}>
              <CardHeader className={`py-2 ${route.tourIndex === 0 ? "bg-blue-600" : "bg-purple-600"} text-white rounded-t-lg`}>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-bold uppercase">
                    {route.tourIndex === 0 ? "1ere" : "2eme"} Tournee
                  </CardTitle>
                  <a
                    href={getGoogleMapsLink(route.tourIndex)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition-colors"
                  >
                    <MapPin className="w-3 h-3" />
                    Google Maps
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </CardHeader>
              <CardContent className="p-0 max-h-48 overflow-y-auto">
                {route.stops.map((stop) => {
                  const apt = apartments.find((a) => a.id === stop.aptId)
                  return (
                    <div key={stop.aptId} className="flex items-start gap-2 p-2 border-b last:border-b-0">
                      <span
                        className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 ${
                          route.tourIndex === 0 ? "bg-blue-600" : "bg-purple-600"
                        }`}
                      >
                        {stop.order}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold truncate">
                          N {apt?.numero} - {apt?.rue}
                        </p>
                        <p className="text-xs text-muted-foreground">{stop.details}</p>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Toolbar */}
        <Card>
          <CardContent className="py-3">
            <div className="flex flex-wrap gap-3 items-center">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher un resident..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={filter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilter("all")}
                  className={filter === "all" ? "bg-slate-800" : ""}
                >
                  Tous ({totalResidents})
                </Button>
                <Button
                  variant={filter === "present" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilter("present")}
                  className={filter === "present" ? "bg-green-600 hover:bg-green-700" : ""}
                >
                  <CheckCircle2 className="w-4 h-4 mr-1" />
                  Presents
                </Button>
                <Button
                  variant={filter === "absent" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilter("absent")}
                  className={filter === "absent" ? "bg-red-600 hover:bg-red-700" : ""}
                >
                  <XCircle className="w-4 h-4 mr-1" />
                  Absents
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Apartments List */}
        <div className="space-y-4">
          {filteredApartments.map((apt) => {
            const ri = rMap[apt.id]
            const isExpanded = expandedApts.has(apt.id) || expandedApts.size === 0
            const aptResps = responsables[apt.id] || []
            const tourClass = ri?.tourIndex === 0 ? "from-blue-600" : ri?.tourIndex === 1 ? "from-purple-600" : "from-slate-600"

            // Filter residents based on search and filter
            let displayResidents = apt.residents
            if (searchQuery) {
              displayResidents = displayResidents.filter(
                (r) =>
                  r.nom.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  r.prenom.toLowerCase().includes(searchQuery.toLowerCase())
              )
            }
            if (filter === "present") {
              displayResidents = displayResidents.filter((r) => {
                const p = getPresence(r.id)
                return p.tour1 === "present" || p.tour2 === "present"
              })
            } else if (filter === "absent") {
              displayResidents = displayResidents.filter((r) => {
                const p = getPresence(r.id)
                return p.tour1 === "absent" || p.tour2 === "absent"
              })
            }

            // Count presence
            const p1 = apt.residents.filter((r) => getPresence(r.id).tour1 === "present").length
            const a1 = apt.residents.filter((r) => getPresence(r.id).tour1 === "absent").length
            const p2 = apt.residents.filter((r) => getPresence(r.id).tour2 === "present").length
            const a2 = apt.residents.filter((r) => getPresence(r.id).tour2 === "absent").length

            return (
              <Card key={apt.id} className="overflow-hidden">
                {/* Apartment Header */}
                <div
                  className={`bg-gradient-to-r ${tourClass} to-slate-700 text-white p-4 cursor-pointer`}
                  onClick={() => toggleExpand(apt.id)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div>
                        <h3 className="font-bold">
                          N {apt.numero} - {apt.rue}
                        </h3>
                        <p className="text-xs text-white/60">
                          {apt.cp} {apt.commune}
                        </p>
                        {ri && (
                          <Badge variant="secondary" className="mt-1 text-xs bg-white/20 text-white border-white/25">
                            <MapPin className="w-3 h-3 mr-1" />
                            {ri.title} - etape {ri.order}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right text-xs">
                        <p className="text-white/60">1ere tournee</p>
                        <p>
                          <span className="text-green-300">{p1}</span> / <span className="text-red-300">{a1}</span>
                        </p>
                      </div>
                      <div className="text-right text-xs">
                        <p className="text-white/60">2eme tournee</p>
                        <p>
                          <span className="text-green-300">{p2}</span> / <span className="text-red-300">{a2}</span>
                        </p>
                      </div>
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <>
                    {/* Apartment Info */}
                    <div className="bg-slate-50 p-3 border-b grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="text-muted-foreground">Etage :</span> {apt.etage}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Observation :</span> {apt.obs || "-"}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Codes :</span>{" "}
                        {apt.codes ? <code className="bg-slate-200 px-1 rounded">{apt.codes}</code> : "-"}
                      </div>
                    </div>

                    {/* Responsables + Apt Signalement */}
                    <div className="bg-blue-50 p-3 border-b flex flex-wrap items-center gap-2 text-xs">
                      {aptResps.length > 0 && (
                        <>
                          <span className="text-blue-600 font-semibold flex items-center gap-1">
                            <User className="w-3 h-3" />
                            Responsables :
                          </span>
                          {aptResps.map((resp, idx) => (
                            <div key={idx} className="flex items-center gap-1">
                              <span className="bg-white border border-blue-200 rounded px-2 py-1 text-blue-600">
                                {resp.name}
                                {resp.phone && ` - ${resp.phone}`}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 p-0"
                                onClick={() => setEditingResponsable({ aptId: apt.id, resp, index: idx })}
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                            </div>
                          ))}
                        </>
                      )}
                      <div className="ml-auto flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingAptSignalement({ aptId: apt.id, aptAddress: `${apt.numero} ${apt.rue}` })}
                          className={`h-7 ${sharedData.aptSignalements[apt.id] ? "border-yellow-500 bg-yellow-100 text-yellow-700" : ""}`}
                        >
                          <AlertTriangle className={`w-3 h-3 mr-1 ${sharedData.aptSignalements[apt.id] ? "text-yellow-600" : ""}`} />
                          {sharedData.aptSignalements[apt.id] ? "Signalement adresse" : "Signaler adresse"}
                        </Button>
                      </div>
                    </div>

                    {/* Show apt signalement if exists */}
                    {sharedData.aptSignalements[apt.id] && (
                      <div className="bg-yellow-50 border-b border-yellow-200 p-3 text-xs">
                        <span className="text-yellow-700 font-semibold flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Evenement adresse : {sharedData.aptSignalements[apt.id]}
                        </span>
                      </div>
                    )}

                    {/* Residents */}
                    <div className="divide-y">
                      {displayResidents.length === 0 ? (
                        <div className="p-4 text-center text-muted-foreground text-sm">Aucun resultat.</div>
                      ) : (
                        displayResidents.map((res) => {
                          const p = getPresence(res.id)
                          const rowClass =
                            p.tour1 === "present" || p.tour2 === "present"
                              ? "bg-green-50"
                              : p.tour1 === "absent" || p.tour2 === "absent"
                              ? "bg-red-50"
                              : ""

                          return (
                            <div key={res.id} className={`p-3 flex flex-wrap items-center gap-4 ${rowClass}`}>
                              {/* Presence Controls */}
                              <div className="flex flex-col gap-1 min-w-[160px]">
                                <div className="flex items-center gap-1">
                                  <span className="text-xs font-bold text-blue-600 w-10">1ere</span>
                                  <Button
                                    variant={p.tour1 === "present" ? "default" : "outline"}
                                    size="sm"
                                    className={`h-7 text-xs ${p.tour1 === "present" ? "bg-green-600 hover:bg-green-700" : ""}`}
                                    onClick={() => setPresence(res.id, "tour1", "present")}
                                  >
                                    <CheckCircle2 className="w-3 h-3 mr-1" />P
                                  </Button>
                                  <Button
                                    variant={p.tour1 === "absent" ? "default" : "outline"}
                                    size="sm"
                                    className={`h-7 text-xs ${p.tour1 === "absent" ? "bg-red-600 hover:bg-red-700" : ""}`}
                                    onClick={() => setPresence(res.id, "tour1", "absent")}
                                  >
                                    <XCircle className="w-3 h-3 mr-1" />A
                                  </Button>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-xs font-bold text-purple-600 w-10">2eme</span>
                                  <Button
                                    variant={p.tour2 === "present" ? "default" : "outline"}
                                    size="sm"
                                    className={`h-7 text-xs ${p.tour2 === "present" ? "bg-green-600 hover:bg-green-700" : ""}`}
                                    onClick={() => setPresence(res.id, "tour2", "present")}
                                  >
                                    <CheckCircle2 className="w-3 h-3 mr-1" />P
                                  </Button>
                                  <Button
                                    variant={p.tour2 === "absent" ? "default" : "outline"}
                                    size="sm"
                                    className={`h-7 text-xs ${p.tour2 === "absent" ? "bg-red-600 hover:bg-red-700" : ""}`}
                                    onClick={() => setPresence(res.id, "tour2", "absent")}
                                  >
                                    <XCircle className="w-3 h-3 mr-1" />A
                                  </Button>
                                </div>
                              </div>

                              {/* Resident Info */}
                              <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-2 min-w-0">
                                <div>
                                  <p className="font-bold text-sm">
                                    {res.nom} {res.prenom}
                                  </p>
                                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                                    <Flag className="w-3 h-3" />
                                    {res.pays || "-"}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                                    <Calendar className="w-3 h-3" />
                                    {res.naiss || "-"}
                                  </p>
                                  <p className="text-xs text-blue-600 font-medium">{getAge(res.naiss)}</p>
                                </div>
                                <div>
                                  <a
                                    href={`tel:${res.tel?.replace(/\./g, "")}`}
                                    className="text-xs text-muted-foreground flex items-center gap-1 hover:text-primary"
                                  >
                                    <Phone className="w-3 h-3" />
                                    {res.tel || "-"}
                                  </a>
                                </div>
                                <div>
                                  {res.chambre && (
                                    <Badge variant="secondary" className="text-xs">
                                      Ch. {res.chambre}
                                    </Badge>
                                  )}
                                </div>
                              </div>

                              {/* Edit Button */}
                              <div className="flex gap-1">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setEditingSignalement({ residentId: res.id, residentName: `${res.nom} ${res.prenom}` })}
                                  className={sharedData.signalements[res.id] ? "border-yellow-500 bg-yellow-50" : ""}
                                >
                                  <AlertTriangle className={`w-4 h-4 ${sharedData.signalements[res.id] ? "text-yellow-600" : ""}`} />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setEditingResident({ apt, resident: res })}
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )
                        })
                      )}
                    </div>
                  </>
                )}
              </Card>
            )
          })}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white/40 text-center py-3 text-xs mt-4">
        Application de suivi de presence - {new Date().toLocaleDateString("fr-FR")} -{" "}
        {currentUserId ? users.find((u) => u.id === currentUserId)?.name : "Aucun utilisateur selectionne"}
      </footer>

      {/* Edit Resident Dialog */}
      <Dialog open={!!editingResident} onOpenChange={(open) => !open && setEditingResident(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifier le resident</DialogTitle>
          </DialogHeader>
          {editingResident && (
            <EditResidentForm
              resident={editingResident.resident}
              onSave={(updated) => saveResident(editingResident.apt.id, updated)}
              onCancel={() => setEditingResident(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Responsable Dialog */}
      <Dialog open={!!editingResponsable} onOpenChange={(open) => !open && setEditingResponsable(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifier le responsable</DialogTitle>
          </DialogHeader>
          {editingResponsable && (
            <EditResponsableForm
              responsable={editingResponsable.resp}
              onSave={(updated) => saveResponsable(editingResponsable.aptId, editingResponsable.index, updated)}
              onCancel={() => setEditingResponsable(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Signalement Dialog */}
      <Dialog open={!!editingSignalement} onOpenChange={(open) => !open && setEditingSignalement(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Evenement a signaler - {editingSignalement?.residentName}</DialogTitle>
          </DialogHeader>
          {editingSignalement && (
            <EditSignalementForm
              signalement={sharedData.signalements[editingSignalement.residentId] || ""}
              onSave={(text) => saveSignalement(editingSignalement.residentId, text)}
              onCancel={() => setEditingSignalement(null)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Users Dialog */}
      <Dialog open={editingUsers} onOpenChange={setEditingUsers}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Modifier les utilisateurs</DialogTitle>
          </DialogHeader>
          <EditUsersForm
            users={users}
            onSave={saveUserName}
            onClose={() => setEditingUsers(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Apt Signalement Dialog */}
      <Dialog open={!!editingAptSignalement} onOpenChange={(open) => !open && setEditingAptSignalement(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Evenement a signaler - {editingAptSignalement?.aptAddress}</DialogTitle>
          </DialogHeader>
          {editingAptSignalement && (
            <EditSignalementForm
              signalement={sharedData.aptSignalements[editingAptSignalement.aptId] || ""}
              onSave={(text) => saveAptSignalement(editingAptSignalement.aptId, text)}
              onCancel={() => setEditingAptSignalement(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Edit Resident Form Component
function EditResidentForm({
  resident,
  onSave,
  onCancel,
}: {
  resident: Resident
  onSave: (resident: Resident) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState(resident)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="nom">Nom</Label>
          <Input id="nom" value={formData.nom} onChange={(e) => setFormData({ ...formData, nom: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="prenom">Prenom</Label>
          <Input
            id="prenom"
            value={formData.prenom}
            onChange={(e) => setFormData({ ...formData, prenom: e.target.value })}
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="pays">Pays d&apos;origine</Label>
          <Input id="pays" value={formData.pays} onChange={(e) => setFormData({ ...formData, pays: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="naiss">Date de naissance</Label>
          <Input
            id="naiss"
            value={formData.naiss}
            onChange={(e) => setFormData({ ...formData, naiss: e.target.value })}
            placeholder="JJ/MM/AAAA"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="tel">Telephone</Label>
          <Input id="tel" value={formData.tel} onChange={(e) => setFormData({ ...formData, tel: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="chambre">N Chambre</Label>
          <Input
            id="chambre"
            value={formData.chambre}
            onChange={(e) => setFormData({ ...formData, chambre: e.target.value })}
          />
        </div>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          Annuler
        </Button>
        <Button onClick={() => onSave(formData)}>Enregistrer</Button>
      </DialogFooter>
    </div>
  )
}

// Edit Responsable Form Component
function EditResponsableForm({
  responsable,
  onSave,
  onCancel,
}: {
  responsable: Responsable
  onSave: (responsable: Responsable) => void
  onCancel: () => void
}) {
  const [formData, setFormData] = useState(responsable)

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nom</Label>
        <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="phone">Telephone</Label>
        <Input
          id="phone"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
        />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          Annuler
        </Button>
        <Button onClick={() => onSave(formData)}>Enregistrer</Button>
      </DialogFooter>
    </div>
  )
}

// Edit Signalement Form Component
function EditSignalementForm({
  signalement,
  onSave,
  onCancel,
}: {
  signalement: string
  onSave: (text: string) => void
  onCancel: () => void
}) {
  const [text, setText] = useState(signalement)

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="signalement">Description de l&apos;evenement</Label>
        <Textarea
          id="signalement"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Decrivez l'evenement a signaler..."
          rows={4}
        />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>
          Annuler
        </Button>
        <Button variant="destructive" onClick={() => onSave("")} disabled={!signalement}>
          Supprimer
        </Button>
        <Button onClick={() => onSave(text)}>Enregistrer</Button>
      </DialogFooter>
    </div>
  )
}

// Edit Users Form Component
function EditUsersForm({
  users,
  onSave,
  onClose,
}: {
  users: { id: string; name: string }[]
  onSave: (userId: string, newName: string) => void
  onClose: () => void
}) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [tempName, setTempName] = useState("")

  const startEdit = (user: { id: string; name: string }) => {
    setEditingId(user.id)
    setTempName(user.name)
  }

  const saveEdit = () => {
    if (editingId && tempName.trim()) {
      onSave(editingId, tempName.trim())
      setEditingId(null)
      setTempName("")
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2 max-h-80 overflow-y-auto">
        {users.map((user) => (
          <div key={user.id} className="flex items-center gap-2 p-2 border rounded">
            {editingId === user.id ? (
              <>
                <Input
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="flex-1"
                  autoFocus
                  onKeyDown={(e) => e.key === "Enter" && saveEdit()}
                />
                <Button size="sm" onClick={saveEdit}>OK</Button>
                <Button size="sm" variant="outline" onClick={() => setEditingId(null)}>X</Button>
              </>
            ) : (
              <>
                <span className="flex-1 font-medium">{user.name}</span>
                <Button size="sm" variant="outline" onClick={() => startEdit(user)}>
                  <Edit2 className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>
        ))}
      </div>
      <DialogFooter>
        <Button onClick={onClose}>Fermer</Button>
      </DialogFooter>
    </div>
  )
}
